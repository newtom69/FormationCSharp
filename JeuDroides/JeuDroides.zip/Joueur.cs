﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JeuDroides.Console.UI
{
    class Joueur
    {
        private string _nom;
        private string _prenom;
    }
}
