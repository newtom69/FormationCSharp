﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JeuDroides.Console.UI
{
    class Humain : Jedi
    {
        public Humain(string nom) : base(nom)
        {
        }
    }
}
