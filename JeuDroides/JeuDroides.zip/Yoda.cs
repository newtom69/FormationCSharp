﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JeuDroides.Console.UI
{
    class Yoda : Jedi
    {
        public Yoda(string nom) : base(nom)
        {
        }
    }
}
